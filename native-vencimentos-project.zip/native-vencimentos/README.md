# Controle de Vencimentos Android — teste
Native WebView wrapper for the existing public app. Does not modify the site.

The native app stores WebView localStorage separately from Chrome. No migration/import occurs automatically. Scheduled WorkManager notifications are best-effort around 8:00 local time and Android battery settings can delay/suppress them. No app-icon badge guarantee.
