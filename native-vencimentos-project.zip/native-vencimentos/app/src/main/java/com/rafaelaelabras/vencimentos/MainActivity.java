package com.rafaelaelabras.vencimentos;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.core.app.ActivityCompat;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.util.concurrent.TimeUnit;

public class MainActivity extends android.app.Activity {
    private static final int REQUEST_POST_NOTIFICATIONS = 501;
    private static final String CHANNEL_ID = "daily_open_tasks";
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(24,59,103));
        createNotificationChannel();
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(243,246,250));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new TaskBridge(this), "AndroidTasks");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (url.startsWith("https://rafaelaelabras-sudo.github.io/controle-vencimentos/")) {
                    view.evaluateJavascript("(function(){try{var d=localStorage.getItem('zapia_due_app_v1');if(d&&window.AndroidTasks)window.AndroidTasks.setTasks(d)}catch(e){}})()", null);
                }
            }
        });
        setContentView(webView);
        webView.loadUrl("https://rafaelaelabras-sudo.github.io/controle-vencimentos/?native=1");
        scheduleDailyWorker();
        requestNotificationPermission();
        WorkManager.getInstance(this).enqueue(new OneTimeWorkRequest.Builder(DailyReminderWorker.class).build());
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_POST_NOTIFICATIONS);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Obrigações em aberto", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Lembrete diário e contador das obrigações ainda não marcadas como pagas.");
            channel.setShowBadge(true);
            ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private void scheduleDailyWorker() {
        long now = System.currentTimeMillis();
        java.util.Calendar next = java.util.Calendar.getInstance();
        next.set(java.util.Calendar.HOUR_OF_DAY, 8); next.set(java.util.Calendar.MINUTE, 0); next.set(java.util.Calendar.SECOND, 0); next.set(java.util.Calendar.MILLISECOND, 0);
        if (next.getTimeInMillis() <= now) next.add(java.util.Calendar.DAY_OF_YEAR, 1);
        long delay = next.getTimeInMillis() - now;
        PeriodicWorkRequest daily = new PeriodicWorkRequest.Builder(DailyReminderWorker.class, 24, TimeUnit.HOURS, 15, TimeUnit.MINUTES)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS).build();
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("daily-open-task-count", ExistingPeriodicWorkPolicy.KEEP, daily);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public static class TaskBridge {
        private final Context context;
        TaskBridge(Context c) { context = c.getApplicationContext(); }
        @JavascriptInterface public void setTasks(String json) {
            context.getSharedPreferences("task_data", Context.MODE_PRIVATE).edit().putString("tasks_json", json).apply();
            WorkManager.getInstance(context).enqueue(new OneTimeWorkRequest.Builder(DailyReminderWorker.class).build());
        }
    }
}
