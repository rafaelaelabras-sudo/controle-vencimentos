package com.rafaelaelabras.vencimentos;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;

public class DailyReminderWorker extends Worker {
    private static final String CHANNEL_ID = "daily_open_tasks";
    public DailyReminderWorker(Context context, WorkerParameters params) { super(context, params); }

    @Override public Result doWork() {
        Context c = getApplicationContext();
        String json = c.getSharedPreferences("task_data", Context.MODE_PRIVATE).getString("tasks_json", "[]");
        int open = countOpenTasks(json);
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success();
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (open <= 0) { nm.cancel(7315); return Result.success(); }
        Intent intent = new Intent(c, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 7315, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification notification = new NotificationCompat.Builder(c, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_agenda)
                .setContentTitle("Obrigações em aberto")
                .setContentText("Você tem " + open + " tarefa(s) para acompanhar. Toque para abrir.")
                .setNumber(open)
                .setBadgeIconType(NotificationCompat.BADGE_ICON_SMALL)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .build();
        NotificationManagerCompat.from(c).notify(7315, notification);
        return Result.success();
    }

    private int countOpenTasks(String json) {
        int count = 0;
        try {
            JSONArray a = new JSONArray(json);
            Calendar now = Calendar.getInstance();
            String monthPeriod = now.get(Calendar.YEAR) + "-" + (now.get(Calendar.MONTH) + 1);
            String yearPeriod = String.valueOf(now.get(Calendar.YEAR));
            for (int i=0;i<a.length();i++) {
                JSONObject item = a.optJSONObject(i); if (item == null || item.optBoolean("disabled", false)) continue;
                String kind = item.optString("kind", "none"); String paid = item.optString("paidPeriod", "");
                String current = (kind.equals("yearly") ? yearPeriod : kind.equals("once") ? "once" : monthPeriod);
                if (!paid.equals(current)) count++;
            }
        } catch (Exception ignored) { return 0; }
        return count;
    }
}
