package br.com.rafaela.vencimentos;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.*;
import java.util.*;

public class DueWorker extends Worker {
  public DueWorker(Context c, WorkerParameters p){super(c,p);}
  @Override public Result doWork(){
    Context c=getApplicationContext();
    try {
      String raw=c.getSharedPreferences("due",0).getString("items","[]");JSONArray arr=new JSONArray(raw);Calendar now=Calendar.getInstance();now.set(Calendar.HOUR_OF_DAY,0);now.set(Calendar.MINUTE,0);now.set(Calendar.SECOND,0);now.set(Calendar.MILLISECOND,0);int count=0;
      for(int i=0;i<arr.length();i++){JSONObject it=arr.optJSONObject(i);if(it==null||it.optBoolean("disabled",false))continue;String kind=it.optString("kind","none");int day=it.optInt("day",0),month=it.optInt("month",0);String paid=it.isNull("paidPeriod")?null:it.optString("paidPeriod",null);String period=period(kind,now);if(period.equals(paid))continue;
        boolean due=false;
        if("none".equals(kind))due=true;
        else if("yearly".equals(kind)&&month>=1&&month<=12&&day==0){due=(now.get(Calendar.MONTH)+1)==month;}
        else {Calendar d=dueDate(kind,day,month,now);if(d!=null)due=!d.after(now);}
        if(due)count++;
      }
      if(count>0&&!(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)){
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"due_daily"):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Controle de Vencimentos").setContentText(count+" obrigação(ões) vencida(s), para hoje ou sem data.").setStyle(new Notification.BigTextStyle().bigText("Confira "+count+" obrigação(ões) vencida(s), para hoje ou sem data. Os prazos futuros não entram nesta contagem." )).setAutoCancel(false).setOngoing(true).setOnlyAlertOnce(true);
        Intent open=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());if(open!=null)b.setContentIntent(PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(4052,b.build());
      }
      Calendar next=Calendar.getInstance();next.set(Calendar.HOUR_OF_DAY,8);next.set(Calendar.MINUTE,0);next.set(Calendar.SECOND,0);next.set(Calendar.MILLISECOND,0);if(next.getTimeInMillis()<=System.currentTimeMillis())next.add(Calendar.DATE,1);androidx.work.OneTimeWorkRequest req=new androidx.work.OneTimeWorkRequest.Builder(DueWorker.class).setInitialDelay(next.getTimeInMillis()-System.currentTimeMillis(),java.util.concurrent.TimeUnit.MILLISECONDS).build();androidx.work.WorkManager.getInstance(c).enqueueUniqueWork("due-daily",androidx.work.ExistingWorkPolicy.REPLACE,req);
      return Result.success();
    }catch(Exception e){return Result.retry();}
  }
  static String period(String kind,Calendar d){if("monthly".equals(kind)||"monthend".equals(kind))return d.get(Calendar.YEAR)+"-"+(d.get(Calendar.MONTH)+1);if("yearly".equals(kind))return String.valueOf(d.get(Calendar.YEAR));if("once".equals(kind))return "once";return d.get(Calendar.YEAR)+"-"+(d.get(Calendar.MONTH)+1);}
  static Calendar dueDate(String kind,int day,int month,Calendar base){Calendar d=(Calendar)base.clone();if("monthend".equals(kind)){d.set(Calendar.DAY_OF_MONTH,d.getActualMaximum(Calendar.DAY_OF_MONTH));}
    else if("monthly".equals(kind)&&day>0){d.set(Calendar.DAY_OF_MONTH,1);d.set(Calendar.DAY_OF_MONTH,Math.min(day,d.getActualMaximum(Calendar.DAY_OF_MONTH)));}
    else if("yearly".equals(kind)&&day>0&&month>=1&&month<=12){int y=base.get(Calendar.YEAR);if(month<base.get(Calendar.MONTH)+1)y++;d.set(Calendar.YEAR,y);d.set(Calendar.MONTH,month-1);d.set(Calendar.DAY_OF_MONTH,1);d.set(Calendar.DAY_OF_MONTH,Math.min(day,d.getActualMaximum(Calendar.DAY_OF_MONTH)));}
    else if("once".equals(kind)&&day>0&&month>=1&&month<=12){d.set(Calendar.MONTH,month-1);d.set(Calendar.DAY_OF_MONTH,1);d.set(Calendar.DAY_OF_MONTH,Math.min(day,d.getActualMaximum(Calendar.DAY_OF_MONTH)));}
    else return null;
    int dow=d.get(Calendar.DAY_OF_WEEK);if(dow==Calendar.SATURDAY)d.add(Calendar.DATE,-1);else if(dow==Calendar.SUNDAY)d.add(Calendar.DATE,-2);return d;}
}
