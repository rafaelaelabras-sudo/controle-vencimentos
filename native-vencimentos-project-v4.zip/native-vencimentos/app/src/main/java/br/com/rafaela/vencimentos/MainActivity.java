package br.com.rafaela.vencimentos;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.NonNull;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.work.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
  static final String URL="https://rafaelaelabras-sudo.github.io/controle-vencimentos/app-v3/";
  WebView web; ValueCallback<Uri[]> fileCallback; static final int FILE_REQUEST=3201;
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff183b67);getWindow().setNavigationBarColor(0xff183b67);createChannel();scheduleDaily();if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},12);
    web=new WebView(this);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(true);web.addJavascriptInterface(new Bridge(),"NativeDue");
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params){
        if(fileCallback!=null)fileCallback.onReceiveValue(null); fileCallback=callback;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");
        try{startActivityForResult(i,FILE_REQUEST);}catch(Exception e){fileCallback=null;callback.onReceiveValue(null);return false;}return true;
      }
    });
    web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){Uri u=r.getUrl();if("https".equals(u.getScheme())&&"rafaelaelabras-sudo.github.io".equals(u.getHost())&&u.getPath().startsWith("/controle-vencimentos/"))return false;startActivity(new Intent(Intent.ACTION_VIEW,u));return true;}
      @Override public void onPageFinished(WebView v,String u){if(trusted(Uri.parse(u)))v.evaluateJavascript("(function(){try{var k='zapia_due_app_v1',s=localStorage; NativeDue.update(s.getItem(k)||'[]');var f=Storage.prototype.setItem;Storage.prototype.setItem=function(a,b){f.call(this,a,b);if(a===k)NativeDue.update(b)}}catch(e){}})()",null);}
    });setContentView(web);web.loadUrl(URL);
  }
  boolean trusted(Uri u){return "https".equals(u.getScheme())&&"rafaelaelabras-sudo.github.io".equals(u.getHost())&&u.getPath().startsWith("/controle-vencimentos/");}
  class Bridge {@JavascriptInterface public void update(String json){if(json==null||json.length()>300000)return;getSharedPreferences("due",0).edit().putString("items",json).apply();scheduleDaily();}}
  void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("due_daily","Lembretes de vencimentos",NotificationManager.IMPORTANCE_DEFAULT);c.setDescription("Contagem contínua de obrigações vencidas, de hoje e sem data.");c.setShowBadge(true);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
  void scheduleDaily(){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,8);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DATE,1);long delay=c.getTimeInMillis()-System.currentTimeMillis();OneTimeWorkRequest req=new OneTimeWorkRequest.Builder(DueWorker.class).setInitialDelay(delay,TimeUnit.MILLISECONDS).build();WorkManager.getInstance(this).enqueueUniqueWork("due-daily",ExistingWorkPolicy.REPLACE,req);}
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_REQUEST&&fileCallback!=null){Uri[] result=(resultCode==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;fileCallback.onReceiveValue(result);fileCallback=null;}}
  @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
