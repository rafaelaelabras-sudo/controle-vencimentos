package br.com.rafaela.vencimentos;

import java.util.Calendar;

/** Local-time WorkManager reminders; deliberately inexact (no exact-alarm permission). */
final class ReminderSchedule {
  private static final int[] HOURS = {8, 12, 16, 20};
  private ReminderSchedule() {}

  static Calendar nextSlot(Calendar now) {
    Calendar next = (Calendar) now.clone();
    next.set(Calendar.MINUTE, 0);
    next.set(Calendar.SECOND, 0);
    next.set(Calendar.MILLISECOND, 0);
    for (int hour : HOURS) {
      next.set(Calendar.HOUR_OF_DAY, hour);
      if (next.after(now)) return next;
    }
    next.add(Calendar.DATE, 1);
    next.set(Calendar.HOUR_OF_DAY, HOURS[0]);
    return next;
  }
}
