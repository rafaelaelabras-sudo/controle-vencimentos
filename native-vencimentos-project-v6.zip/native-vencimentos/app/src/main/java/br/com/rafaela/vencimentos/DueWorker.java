package br.com.rafaela.vencimentos;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.ExistingWorkPolicy;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Private, on-device daily summary. No obligation names or details leave the device. */
public class DueWorker extends Worker {
  private static final String CHANNEL = "due_daily_v6";
  private static final int NOTIFICATION_ID = 4052;
  public DueWorker(Context c, WorkerParameters p) { super(c, p); }

  @Override public Result doWork() {
    Context c = getApplicationContext();
    try {
      JSONArray arr = new JSONArray(c.getSharedPreferences("due", 0).getString("items", "[]"));
      Calendar today = midnight(Calendar.getInstance());
      Calendar tomorrow = (Calendar) today.clone(); tomorrow.add(Calendar.DATE, 1);
      int overdue = 0, dueToday = 0, dueTomorrow = 0, noDate = 0;
      for (int i = 0; i < arr.length(); i++) {
        JSONObject it = arr.optJSONObject(i);
        if (it == null || it.optBoolean("disabled", false)) continue;
        String kind = it.optString("kind", "none");
        int day = it.optInt("day", 0), month = it.optInt("month", 0);
        String paid = it.isNull("paidPeriod") ? null : it.optString("paidPeriod", null);
        String currentPeriod = period(kind, today);
        if (currentPeriod.equals(paid)) {
          // Paid current cycle: evaluate next cycle only for tomorrow notices.
          Calendar next = nextOccurrence(it, today);
          if (next != null && sameDay(next, tomorrow)) dueTomorrow++;
          continue;
        }
        if ("none".equals(kind)) { noDate++; continue; }
        if ("yearly".equals(kind) && month >= 1 && month <= 12 && day == 0) {
          if (today.get(Calendar.MONTH) + 1 == month) noDate++;
          continue;
        }
        Calendar due = currentOccurrence(it, today);
        if (due == null) continue;
        if (due.before(today)) overdue++;
        else if (sameDay(due, today)) dueToday++;
        else if (sameDay(due, tomorrow)) dueTomorrow++;
      }
      int count = overdue + dueToday + dueTomorrow + noDate;
      NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
      boolean allowed = Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
      if (count > 0 && allowed) {
        String summary = "Vencidas: " + overdue + " · hoje: " + dueToday + " · amanhã: " + dueTomorrow + " · sem data: " + noDate;
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
          .setContentTitle("Controle de Vencimentos")
          .setContentText(summary)
          .setStyle(new Notification.BigTextStyle().bigText(summary + ". Abra o app para conferir sua lista."))
          .setNumber(count).setOngoing(true).setOnlyAlertOnce(false).setAutoCancel(false)
          .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
        Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (open != null) b.setContentIntent(PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        // Remove the prior same-ID notification first so Android treats each scheduled check as a fresh alert.
        nm.cancel(NOTIFICATION_ID);
        nm.notify(NOTIFICATION_ID, b.build());
      } else if (count == 0) {
        nm.cancel(NOTIFICATION_ID);
      }
      scheduleNext(c);
      return Result.success();
    } catch (Exception e) { return Result.retry(); }
  }

  static void scheduleNext(Context c) {
    Calendar next = ReminderSchedule.nextSlot(Calendar.getInstance());
    OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(DueWorker.class).setInitialDelay(next.getTimeInMillis() - System.currentTimeMillis(), TimeUnit.MILLISECONDS).build();
    WorkManager.getInstance(c).enqueueUniqueWork("due-daily", ExistingWorkPolicy.APPEND_OR_REPLACE, req);
  }

  static Calendar currentOccurrence(JSONObject it, Calendar base) {
    String kind = it.optString("kind", "none"); int day = it.optInt("day", 0), month = it.optInt("month", 0);
    if ("weekly".equals(kind)) { Calendar d=weeklyDate(it.optInt("weekday", -1), base); if(d!=null && d.before(base)) d.add(Calendar.DATE,7); return d; }
    if ("monthend".equals(kind) || "monthly".equals(kind)) return dueDate(kind, day, month, base);
    if ("yearly".equals(kind) && month >= 1 && month <= 12 && day > 0) {
      Calendar d = (Calendar) base.clone(); d.set(Calendar.MONTH, month - 1); d.set(Calendar.DAY_OF_MONTH, 1); d.set(Calendar.DAY_OF_MONTH, Math.min(day, d.getActualMaximum(Calendar.DAY_OF_MONTH))); adjustWeekend(d); return d;
    }
    if ("once".equals(kind) && month >= 1 && month <= 12 && day > 0) {
      Calendar d = (Calendar) base.clone(); d.set(Calendar.MONTH, month - 1); d.set(Calendar.DAY_OF_MONTH, 1); d.set(Calendar.DAY_OF_MONTH, Math.min(day, d.getActualMaximum(Calendar.DAY_OF_MONTH))); adjustWeekend(d); return d;
    }
    return null;
  }

  static Calendar nextOccurrence(JSONObject it, Calendar base) {
    String kind = it.optString("kind", "none"); int day = it.optInt("day", 0), month = it.optInt("month", 0);
    if ("weekly".equals(kind)) { Calendar d = weeklyDate(it.optInt("weekday", -1), base); if (d != null) d.add(Calendar.DATE, 7); return d; }
    if ("monthly".equals(kind) || "monthend".equals(kind)) { Calendar b=(Calendar)base.clone(); b.add(Calendar.MONTH,1); return dueDate(kind,day,month,b); }
    if ("yearly".equals(kind) && month >= 1 && month <= 12 && day > 0) { Calendar b=(Calendar)base.clone(); b.add(Calendar.YEAR,1); return currentOccurrence(it,b); }
    return null;
  }
  static Calendar midnight(Calendar d) { d.set(Calendar.HOUR_OF_DAY,0); d.set(Calendar.MINUTE,0); d.set(Calendar.SECOND,0); d.set(Calendar.MILLISECOND,0); return d; }
  static boolean sameDay(Calendar a, Calendar b) { return a.get(Calendar.YEAR)==b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR)==b.get(Calendar.DAY_OF_YEAR); }
  static String period(String kind, Calendar d) {
    if ("weekly".equals(kind)) { Calendar m=(Calendar)d.clone(); m.add(Calendar.DATE,-((m.get(Calendar.DAY_OF_WEEK)+5)%7)); return String.format(Locale.US,"week-%04d-%02d-%02d",m.get(Calendar.YEAR),m.get(Calendar.MONTH)+1,m.get(Calendar.DAY_OF_MONTH)); }
    if ("monthly".equals(kind)||"monthend".equals(kind)) return d.get(Calendar.YEAR)+"-"+(d.get(Calendar.MONTH)+1);
    if ("yearly".equals(kind)) return String.valueOf(d.get(Calendar.YEAR));
    if ("once".equals(kind)) return "once";
    return d.get(Calendar.YEAR)+"-"+(d.get(Calendar.MONTH)+1);
  }
  static Calendar weeklyDate(int weekday, Calendar base) {
    if (weekday<0||weekday>6) return null;
    Calendar d=(Calendar)base.clone(); d.add(Calendar.DATE,-((d.get(Calendar.DAY_OF_WEEK)+5)%7));
    int offset=(weekday==0||weekday==6)?4:weekday-1; d.add(Calendar.DATE,offset); return midnight(d);
  }
  static Calendar dueDate(String kind, int day, int month, Calendar base) {
    Calendar d=(Calendar)base.clone();
    if ("monthend".equals(kind)) d.set(Calendar.DAY_OF_MONTH,d.getActualMaximum(Calendar.DAY_OF_MONTH));
    else if ("monthly".equals(kind)&&day>0) { d.set(Calendar.DAY_OF_MONTH,1); d.set(Calendar.DAY_OF_MONTH,Math.min(day,d.getActualMaximum(Calendar.DAY_OF_MONTH))); }
    else return null;
    adjustWeekend(d); return midnight(d);
  }
  static void adjustWeekend(Calendar d) { int dow=d.get(Calendar.DAY_OF_WEEK); if(dow==Calendar.SATURDAY)d.add(Calendar.DATE,-1); else if(dow==Calendar.SUNDAY)d.add(Calendar.DATE,-2); }
}
