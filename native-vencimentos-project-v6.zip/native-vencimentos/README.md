# Controle de Vencimentos v5 (projeto Android)

Projeto Android nativo, separado do app v4. Veja `../../README.md` para pacote, dados, comportamento de avisos e limitações de distribuição.
